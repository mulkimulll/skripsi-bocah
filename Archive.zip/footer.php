    <div class="footer mt-4 bg-dark text-white pt-3 pb-2">
      <div class="container">
        Copyright <?= date('Y');?> <?= $info_web->nama_rental;?> All Reserved
      </div>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
  </body>
</html>