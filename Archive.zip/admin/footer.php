    <div class="footer mt-4 bg-dark text-white pt-3 pb-2">
      <div class="container">
        Copyright <?= date('Y');?> <?= $info_web->nama_rental;?> All Reserved
      </div>
    </div>
    <script src="<?php echo $url;?>assets/js/jquery-3.3.1.min.js"></script>
    <script src="<?php echo $url;?>assets/js/bootstrap.min.js"></script>
  </body>
</html>